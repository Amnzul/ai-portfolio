---
name: sec-filing-analysis
description: >
  Expert guidance for reading and extracting signal from SEC filings including 10-K, 10-Q,
  8-K, DEF 14A (proxy), S-1, and Form 4. Trigger this skill whenever the user wants to analyze
  a specific filing, asks about red flags in a company's financials, mentions footnotes,
  MD&A, auditor issues, related-party transactions, or asks "what should I look for" in
  any SEC document. Also trigger when the user pastes or uploads filing content for review.
  Use alongside equity-due-diligence for comprehensive company analysis.
---

# SEC Filing Analysis

Always fetch the most recent filing from SEC EDGAR (https://www.sec.gov/cgi-bin/browse-edgar)
or a financial data aggregator before analysis. Never rely on memory for filing contents.

---

## Filing Type Quick Reference

| Filing | Frequency | What It Contains |
|--------|-----------|-----------------|
| 10-K   | Annual    | Full audited financials, MD&A, risk factors, business description |
| 10-Q   | Quarterly | Unaudited quarterly financials, MD&A updates |
| 8-K    | Event-driven | Material events: earnings, M&A, exec changes, restatements |
| DEF 14A | Annual  | Proxy: exec compensation, board composition, shareholder votes |
| Form 4 | Within 2 days of trade | Insider buying/selling |
| S-1    | One-time  | IPO registration: full business + risk disclosure |

---

## 10-K Deep Dive Checklist

### Business Section (Item 1)
- [ ] How does the company describe its competitive advantages? (compare to what analysts say)
- [ ] Has the business description changed materially YoY? (suggests strategic shift)
- [ ] Customer concentration disclosure — any customer >10% of revenue?
- [ ] Geographic revenue breakdown

### Risk Factors (Item 1A)
- [ ] Are new risk factors added vs. prior year? New risks = management acknowledging new threats
- [ ] Look for boilerplate vs. specific risks — specific risks are more informative
- [ ] AI/technology disruption risks: is management being candid or generic?
- [ ] Regulatory and litigation risks — any that are material and active?

### MD&A (Item 7) — Highest Signal Section
Focus on:
- Revenue bridge: what drove growth (volume vs. price vs. mix)?
- Gross margin explanation: what caused any change?
- Operating expense commentary: is management explaining investments or papering over spending?
- **Liquidity and Capital Resources**: cash flow discussion, credit facility terms, covenant headroom
- **Known trends**: what is management flagging as forward headwinds/tailwinds?
- Compare language YoY — softening language on growth = early warning signal

### Financial Statements

**Income Statement:**
- Revenue recognition policy (Note 1 or 2) — has it changed?
- Deferred revenue trend: growing deferred revenue is a positive leading indicator
- Segment reporting: are margins expanding or contracting in key segments?

**Balance Sheet:**
- Accounts receivable vs. revenue growth — AR growing faster = collection risk or channel stuffing
- Goodwill and intangibles as % of total assets — large % means acquisition-driven growth
- Deferred revenue on balance sheet (liability) — bigger = more locked-in future revenue
- Off-balance-sheet obligations (operating leases, commitments)

**Cash Flow Statement:**
- Stock-based compensation add-back: large = real dilutive cost being excluded from earnings
- Working capital changes: unsustainable boosts to operating cash flow
- CapEx trend: increasing CapEx in a software company = something changed

### Footnotes (Most Investors Skip — Don't)
Priority footnotes:
1. **Revenue recognition** — when and how they book revenue; any changes are significant
2. **Segment information** — true profitability by business line
3. **Related party transactions** — any dealings between company and executives/directors
4. **Debt and commitments** — full terms, covenants, maturity wall
5. **Subsequent events** — things that happened after quarter close but before filing
6. **Concentration of credit risk** — customer/vendor concentration

---

## 10-Q Quarterly Checklist

Focus on delta vs. prior quarter and prior year quarter:
- [ ] Revenue growth rate: accelerating or decelerating?
- [ ] Gross margin: any sequential compression?
- [ ] Operating cash flow: seasonal or structural change?
- [ ] Deferred revenue: growing (good) or shrinking (concerning for SaaS)?
- [ ] Any new risk factors added mid-year?
- [ ] Management tone in MD&A: more or less confident than last quarter?

---

## 8-K High-Priority Events

These 8-Ks demand immediate attention:
- **Item 4.01/4.02**: Auditor change or disagreement — major red flag
- **Item 5.02**: CEO/CFO departure — assess whether voluntary or forced
- **Item 2.06**: Material impairment — often signals prior over-payment on acquisitions
- **Item 4.02**: Non-reliance on prior financials — restatement incoming
- **Item 1.01**: Material definitive agreement — M&A, major partnership, or debt deal

---

## Proxy Statement (DEF 14A) Checklist

### Executive Compensation
- [ ] Is pay tied to revenue growth, margins, or stock performance? (reveals incentive alignment)
- [ ] Large guaranteed bonuses regardless of performance = misaligned incentives
- [ ] CEO pay ratio vs. median employee — very high ratios can signal culture issues
- [ ] Accelerated vesting on change of control — entrenchment risk

### Board Quality
- [ ] Board independence: majority independent directors?
- [ ] Key committee independence: Audit, Compensation, Nominating should be fully independent
- [ ] Director tenure: very long tenure = staleness; very short = inexperienced
- [ ] Related-party transactions approved by the board — conflicts of interest?

### Shareholder Votes
- [ ] "Say on pay" approval rate: <70% = significant investor dissatisfaction
- [ ] Any contested elections or activist proposals?
- [ ] Dual-class share structure: founders retain voting control (pro: vision; con: entrenchment)

---

## Red Flag Summary Checklist

Run through these on every 10-K/10-Q:

**Accounting Red Flags:**
- [ ] Auditor change (especially mid-year)
- [ ] Going concern language in auditor opinion
- [ ] Restatement of prior financials
- [ ] Material weakness in internal controls
- [ ] Revenue recognition change without clear business rationale
- [ ] AR days increasing faster than revenue growth
- [ ] Large and growing gap between net income and operating cash flow

**Business Red Flags:**
- [ ] Key customer departures or concentration increase
- [ ] Founder/CEO/CFO departure without clear succession
- [ ] Significant related-party transactions
- [ ] Guidance withdrawal or refusal to provide guidance
- [ ] Repeated "one-time" charges that recur every quarter

**Governance Red Flags:**
- [ ] Dual-class shares with no sunset provision
- [ ] Board entrenchment mechanisms (staggered board, poison pill)
- [ ] Low say-on-pay approval (<70%)
- [ ] Frequent auditor or board member turnover

---

## EDGAR Navigation Tips

Quick links:
- All filings for a company: `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=[TICKER]&type=&dateb=&owner=include&count=40`
- Replace `[TICKER]` with the company's ticker symbol
- Filter by filing type (10-K, 10-Q, 8-K, DEF 14A, 4) using the Type field
- EDGAR full-text search: `efts.sec.gov/LATEST/search-index?q=[search term]&dateRange=custom`
