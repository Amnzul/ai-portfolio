---
name: competitive-landscape
description: >
  Framework for mapping competitive dynamics, assessing moat durability, and identifying
  disruption risks for any publicly traded company. Trigger this skill when the user asks
  about competitors, market share, industry structure, disruption risk, or whether a company
  has a defensible position. Also trigger for questions like "who are the competitors of X",
  "is X's moat durable", "could AI disrupt X", or "what's the competitive dynamic in [industry]".
  Use alongside equity-due-diligence for comprehensive analysis.
---

# Competitive Landscape Analysis

## Overview

Understanding competitive dynamics is essential for growth investing — the durability of
growth depends almost entirely on whether the company can defend and expand its position.
Always fetch current news, recent analyst reports, and competitor filings before assessing.

---

## Step 1: Industry Structure (Porter's Five Forces)

Rate each force: **High / Medium / Low** pressure on the subject company

### Competitive Rivalry
- How many direct competitors? Are they well-funded?
- Is the market winner-take-all, winner-take-most, or fragmented?
- Is pricing power intact or eroding (price wars)?
- Are competitors growing faster or slower?

### Threat of New Entrants
- Capital requirements to enter (high = protective)
- Regulatory barriers (licenses, compliance costs)
- Technology barriers (proprietary IP, data advantages, years of model training)
- Brand/distribution advantages of incumbents
- **AI-specific**: is the barrier to building a competing product falling due to AI tools?

### Threat of Substitutes
- Can customers solve their problem with a fundamentally different approach?
- Is "do nothing" or "build in-house" a viable substitute?
- Are customers increasingly using multi-vendor approaches?

### Buyer Power
- Customer concentration: does any single buyer have leverage?
- Are customers price-sensitive or outcome-sensitive?
- Switching costs: high switching costs = low buyer power
- Contract length and renewal patterns

### Supplier Power
- Key dependencies: cloud infrastructure (AWS/Azure/GCP), data providers, talent
- Can suppliers raise costs materially? (e.g., GPU costs for AI companies)
- Single-source vs. multi-source dependencies

---

## Step 2: Competitive Positioning Map

Plot the competitive set on two dimensions most relevant to the industry.
Common dimension pairs:
- Enterprise vs. SMB customer focus / Feature depth vs. Ease of use
- Cost leadership vs. Product differentiation
- Horizontal platform vs. Vertical specialist
- Legacy incumbent vs. Cloud-native challenger

For each major competitor, assess:
| Competitor | Funding/Size | Primary Strength | Primary Weakness | Growth Rate |
|------------|-------------|-----------------|-----------------|-------------|

---

## Step 3: Moat Analysis

### Moat Sources (assess each)

**Switching Costs**
- How painful is it to rip out and replace the product?
- Technical integration depth (API connections, data migration, retraining)
- Organizational/workflow embedding (how many people touch it daily?)
- Contractual lock-in (multi-year deals, volume commitments)
- *High switching cost signals*: ERP/infrastructure software, payroll systems, core banking

**Network Effects**
- Direct network effects: product improves as more users join the same network
- Indirect/marketplace network effects: more supply → better for demand and vice versa
- Data network effects: more usage generates more data which improves the product
- *Rate each*: Strong / Emerging / Claimed but weak / None

**Data Advantages**
- Does the company have proprietary data that competitors cannot replicate?
- Is the data advantage self-reinforcing (more usage = better data = better product)?
- Is data increasingly commoditized in this domain (e.g., due to open datasets, LLMs)?

**Scale Advantages**
- Does unit cost decline meaningfully with scale?
- Can the company undercut competitors on price and still improve margins?
- R&D scale: can they invest more in product than challengers?

**Brand**
- Does the brand command a premium or generate pull in the sales cycle?
- B2B brand = trust, reliability, security; B2C brand = identity, aspiration

---

## Step 4: Disruption Risk Assessment

### Technology Disruption Framework

For each new technology vector (AI, new infrastructure, regulation), ask:

1. **Is this technology a substitute or an enabler?**
   - Substitute: threatens the existing product (e.g., AI coding tools vs. certain SaaS)
   - Enabler: allows the company to build a better product faster

2. **Who is best positioned to exploit this technology?**
   - Incumbent (has distribution, data, and customer relationships)
   - Challenger (can build natively on new stack without legacy constraints)
   - Big Tech (has compute, talent, and can bundle)

3. **What is the timeline of disruption?**
   - Near-term (<2 years): watch actively, quantify risk
   - Medium-term (2–5 years): monitor leading indicators
   - Long-term (5+ years): acknowledge but don't over-discount

### AI Disruption Checklist (apply to any company)
- [ ] Does the company's core value proposition involve a task AI can now automate?
- [ ] Is the company's per-seat pricing model at risk from usage-based AI agents?
- [ ] Is the company building AI into its own product? (offensive vs. defensive posture)
- [ ] Are customers experimenting with AI alternatives? (check earnings call Q&A)
- [ ] What does management say about AI? Specific roadmap = engaged; vague = behind

---

## Step 5: Market Share Analysis

- What is the company's current market share (revenue basis)?
- Is it gaining or losing share? (grow faster or slower than the market)
- Source of share gain: taking from competitors, or expanding the overall pie?
- Are there any share loss signals: customer win/loss data, partner ecosystem shifts, job postings (competitors hiring aggressively in this market)?

---

## Step 6: Competitive Moat Verdict

Summarize into a single moat rating:

| Rating | Definition |
|--------|-----------|
| **Wide Moat** | Multiple reinforcing advantages; disruption would require sustained effort over years |
| **Narrow Moat** | One clear advantage but vulnerable to a well-resourced challenger |
| **Moat in Formation** | Company is building advantages but not yet durable |
| **No Moat** | Competing primarily on price or temporary product lead; high churn risk |

Support rating with 2–3 specific evidence points.

---

## Output Format

```
COMPETITIVE LANDSCAPE: [Company Name]

INDUSTRY STRUCTURE: [Porter's summary — 2-3 sentences]

COMPETITIVE SET:
  Primary competitors: [list with one-line descriptor each]
  Emerging threats: [newer entrants or adjacent players]

MOAT RATING: [Wide / Narrow / In Formation / None]
  Key moat source(s): [bullet points with evidence]
  Moat risks: [what could erode it]

DISRUPTION RISK: [High / Medium / Low]
  Primary vector: [AI / new entrant / commoditization / regulatory]
  Timeline: [near / medium / long]
  Company's response: [offensive / defensive / unclear]

MARKET SHARE TREND: [Gaining / Holding / Losing]
  Evidence: [specific data points]

BOTTOM LINE: [2-3 sentences — is the competitive position a reason to own, monitor, or avoid?]
```
