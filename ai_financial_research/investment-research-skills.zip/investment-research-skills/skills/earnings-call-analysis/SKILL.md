---
name: earnings-call-analysis
description: >
  Specialized framework for extracting maximum signal from earnings call transcripts and
  earnings releases. Trigger this skill whenever the user shares an earnings transcript,
  asks about what management said on a call, wants to analyze earnings results, asks about
  guidance, or asks to compare what a company said across multiple quarters. Also trigger
  for post-earnings analysis ("how should I interpret these results?", "was this a good
  quarter?"). Always fetch the most recent transcript if not provided.
---

# Earnings Call Analysis

Earnings calls are one of the highest-signal inputs in growth investing. Management tone,
word choice, analyst question patterns, and guidance framing all carry information beyond
the headline numbers. Always fetch the transcript and the earnings release press release —
they contain different information.

---

## Pre-Call Preparation

Before listening or reading, gather:
- [ ] Consensus estimates for revenue, EPS, and key metrics (fetch current)
- [ ] Company guidance from the prior quarter
- [ ] Key debates/concerns from analyst community going into the call
- [ ] Stock price reaction pre-market or intraday (market's real-time verdict)

---

## Earnings Release (Press Release) Analysis

Work through the press release before the transcript:

### Headline Metrics
- Revenue: actual vs. consensus vs. prior guide
- Gross margin: actual vs. consensus and sequential trend
- Operating income / EPS: GAAP and non-GAAP — note the delta
- Key operational metrics (ARR, NRR, DAU, GMV — whatever is primary for this business)

### Guidance Framing
- What did they guide for next quarter?
- Full-year guidance: raised, maintained, or lowered?
- Is guidance above or below consensus? By how much?
- Watch for: guidance that "beats and raises" vs. "meets and maintains" vs. "beats but lowers" (worst)

### Beats/Misses Quality Assessment
Not all beats are equal:
- **High quality beat**: revenue + key metrics + forward guidance all above consensus
- **Mixed beat**: revenue beats but guidance is light (often sells off)
- **Low quality beat**: small revenue beat with margin miss and/or guidance cut
- **Beat on non-GAAP, miss on GAAP**: investigate what's being excluded

---

## Transcript Analysis

### CEO Opening Remarks
Read for:
- Which metrics does management lead with? (they emphasize what's working)
- What's conspicuously absent from the discussion? (they avoid what's not)
- Language changes vs. prior quarter — softer on growth = watch carefully
- New strategic initiatives announced — bullish if expanding TAM, concerning if it signals current business weakness

**Linguistic signals to flag:**
| Language | Interpretation |
|----------|---------------|
| "We're seeing strong momentum" | Positive — look for data to back it up |
| "We remain focused on efficiency" | Margins under pressure, growth potentially slowing |
| "Macro headwinds" used repeatedly | External blame — assess validity |
| "Investing for long-term growth" without specifics | Can be cover for margin miss |
| Specific customer wins named | Confidence — they want you to know |
| Vague revenue driver language | Lack of visibility or desire to obscure |

### CFO Remarks
The CFO section is often more informative than the CEO section for financial analysis:
- Revenue bridge: what drove growth (new logos vs. expansion vs. price)
- Gross margin explanation: infrastructure investment? pricing changes? mix shift?
- OpEx: are they investing or cutting? (R&D vs. S&M ratio)
- Cash flow: was FCF generation real or aided by working capital timing?
- Share count: any buybacks or net dilution?

### Q&A Section — Highest Signal

The Q&A is where the prepared script ends and real information emerges.

**Analyst question patterns to watch:**
- Questions asked by multiple analysts = topic the Street is worried about
- Follow-up questions on the same topic = management first answer was unsatisfying
- Pushback on guidance = analysts don't believe the numbers

**Management answer quality:**
- Direct answer with data = confident and transparent
- Redirected to a different metric = avoiding the question
- "We don't guide on that" repeated = topic is sensitive
- Long, meandering answer = either complex genuinely, or stalling
- Short answer on a normally important metric = potentially hiding deterioration

**Specific question categories to track:**
1. Churn / NRR questions (for SaaS)
2. Pipeline / bookings health
3. Macro sensitivity
4. Competitive dynamics
5. Hiring and headcount
6. New product traction
7. International performance
8. Large deal / enterprise penetration

---

## Quarter-over-Quarter Comparison

When analyzing multiple quarters, build this table:

| Metric | Q-4 | Q-3 | Q-2 | Q-1 | Most Recent |
|--------|-----|-----|-----|-----|-------------|
| Revenue YoY growth |  |  |  |  |  |
| Gross margin |  |  |  |  |  |
| NRR / key metric |  |  |  |  |  |
| Rule of 40 |  |  |  |  |  |
| Guidance vs. beat |  |  |  |  |  |
| Management tone* |  |  |  |  |  |

*Tone: 1 (very cautious) → 5 (very confident) — subjective but useful as a time series

Look for trend breaks — a company that has beaten estimates 8 quarters in a row showing first signs of guidance conservatism is a different situation than a chronic miss-and-lower company.

---

## Post-Earnings Synthesis

Answer these five questions:

1. **Did the business perform better or worse than what was implied in the stock price?**
   (Not just vs. consensus — vs. what the valuation was pricing in)

2. **Did the growth story strengthen, weaken, or stay the same?**
   (Durability of the growth thesis is more important than one quarter)

3. **Did management credibility increase or decrease?**
   (Did they do what they said they'd do last quarter?)

4. **What is the key debate going forward?**
   (What question was raised by this quarter that will drive the stock next quarter?)

5. **Does the valuation still make sense given what we learned?**
   (Quick sanity check: what multiple is the market paying for revised estimates?)

---

## One-Quarter Summary Output Format

```
[TICKER] Q[X] [YEAR] Earnings Summary

HEADLINE: [Beat/Miss/In-line] on revenue | [Beat/Miss/In-line] on key metric | Guide [Above/Below/In-line]

NUMBERS:
  Revenue: $Xm (est. $Xm, +X% YoY)
  Gross Margin: X% (vs X% last Q, X% a year ago)
  [Key Metric]: X (est. X)
  FCF Margin: X%
  Rule of 40: X

GUIDANCE:
  Next Q revenue: $X–$X (consensus: $X)
  Full year: [raised/maintained/lowered] to $X–$X

BULL POINTS:
  • [2-3 things that were better than expected]

BEAR POINTS:
  • [2-3 things that were concerning or worse than expected]

KEY QUOTE: "[Most important thing management said in Q&A]"

VERDICT: [1-2 sentence synthesis — does this quarter change the thesis?]
```
