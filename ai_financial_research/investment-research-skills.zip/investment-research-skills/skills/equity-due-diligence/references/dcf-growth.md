# DCF Framework for Growth Companies

Growth company DCFs are dominated by terminal value (often 70–90% of total value),
so assumptions about long-run margins and discount rates matter far more than near-term forecasts.

---

## Step 1: Projection Period (Years 1–10)

### Revenue Build
- Start from most recent TTM revenue (fetch current figure)
- Use analyst consensus for Years 1–3, then taper to a "steady-state" growth rate by Year 10
- Taper should reflect market maturation, not wishful thinking

Suggested taper for growth company:
| Year | Growth Rate Source |
|------|--------------------|
| 1–2  | Management guide / consensus |
| 3–5  | Slight haircut to consensus (5–15%) |
| 6–8  | Gradual taper toward 10–15% |
| 9–10 | Approaching terminal growth rate (3–6%) |

### Margin Expansion Build
Growth companies are often unprofitable or low-margin today. Model the path to mature margins:
- Identify a comp set of mature peers in the same industry
- Use their FCF margins as the terminal margin target
- Model linear or S-curve expansion from current to terminal
- Common range: SaaS terminal FCF margins 20–30%; marketplace 15–25%; hardware-software mix varies

### Free Cash Flow = Revenue × FCF Margin (simplified)
For early-stage companies, use:
`FCF = (Revenue × Gross Margin) − Fixed Operating Costs − CapEx`

---

## Step 2: Terminal Value

Use Gordon Growth Model:
`TV = FCF_Year10 × (1 + g) / (WACC − g)`

Where:
- `g` = terminal growth rate (typically 3–5% for durable businesses; don't exceed long-run nominal GDP growth)
- `WACC` = weighted average cost of capital (see below)

**Key sensitivity**: Terminal value is highly sensitive to (WACC − g). A 1% change in either
can move intrinsic value 20–40%. Always run a sensitivity table on these two variables.

---

## Step 3: Discount Rate (WACC)

For growth companies, WACC is typically higher than mature companies due to:
- Higher equity risk premium
- Often no debt (pure equity financing)
- Business model execution risk

Suggested starting ranges:
| Company Stage | WACC Range |
|---------------|-----------|
| Pre-profit, high growth | 12–15% |
| Growth with improving margins | 10–13% |
| Growth + FCF positive | 9–11% |
| Mature growth | 8–10% |

Use CAPM for equity cost: `Ke = Rf + β × (Rm − Rf)`
- Risk-free rate: use current 10-year Treasury yield (fetch current rate)
- Equity risk premium: 5–6% standard
- Beta: use 2-year weekly beta from a financial data source

---

## Step 4: Sensitivity Tables (Required)

Always produce two sensitivity tables:

**Table 1: Intrinsic Value vs. WACC and Terminal Growth Rate**
```
          WACC
g    |  9%  | 10%  | 11%  | 12%  | 13%
-----|------|------|------|------|-----
 3%  |      |      |      |      |
 4%  |      |      |      |      |
 5%  |      |      |      |      |
```

**Table 2: Intrinsic Value vs. Year 5 Revenue Growth and Terminal FCF Margin**
```
               Terminal FCF Margin
Rev Growth | 15%  | 20%  | 25%  | 30%
-----------|------|------|------|-----
 Low       |      |      |      |
 Base      |      |      |      |
 High      |      |      |      |
```

---

## Step 5: Implied Metrics Check

After building the DCF, sanity check against market multiples:
- What EV/NTM Revenue does your base case imply?
- How does that compare to current trading multiple?
- Does the market appear to be pricing a bull, base, or bear scenario?

This "reverse DCF" framing is often more useful for growth stocks than a forward DCF,
because it lets you ask: "what does the market need to believe for this price to be fair?"

---

## Common DCF Mistakes for Growth Companies

1. **Using near-term margins as terminal margins** — growth companies invest heavily; terminal margins should reflect maturity, not current state
2. **Ignoring dilution** — always use fully diluted share count including options and converts
3. **Single-point estimate** — always run scenarios; a single DCF number is false precision
4. **Forgetting net cash/debt** — adjust enterprise value by net cash position to get equity value
5. **Anchoring on current price** — build the model bottom-up, then compare to price; don't reverse-engineer to justify a pre-existing view
