---
name: equity-due-diligence
description: >
  Comprehensive due diligence workflow for publicly traded growth and momentum companies.
  Trigger this skill whenever the user asks to analyze, research, evaluate, or do a deep dive
  on a public company — even if phrased casually ("what do you think of $NVDA", "help me
  research this stock", "is X worth buying", "break down this company for me"). Also trigger
  for requests to build an investment thesis, assess upside/downside, or compare two companies.
  Do NOT use for purely macroeconomic questions or ETF analysis.
---

# Equity Due Diligence — Growth & Momentum Framework

## Overview

This skill produces a structured, research-grade analysis of a publicly traded company using
a growth-first lens. Always fetch current data (recent filings, earnings, price action) via
web search before beginning analysis. Never rely on memory for financials, guidance, or news.

---

## Phase 1: Business Intelligence

### 1.1 Business Model
- What does the company sell, and to whom? (B2B / B2C / marketplace / platform)
- How does it make money? (subscription, usage-based, transactional, licensing, ads)
- What is the unit economics model? (CAC, LTV, payback period if disclosable)
- What is the **primary growth driver** right now — new logos, expansion revenue, or price?

### 1.2 TAM & Market Position
- Define the serviceable TAM with a source. Be skeptical of company-provided TAM figures.
- What is current penetration? Is the market growing, stable, or contracting?
- Where does the company sit in the competitive stack? (leader, challenger, niche)
- Is the TAM expanding due to a secular tailwind (AI, cloud migration, regulatory shift, etc.)?

### 1.3 Moat Assessment
Rate each of the following: **Strong / Developing / Weak / None**
- Switching costs
- Network effects
- Data advantages
- Scale/cost advantages
- Brand
- Regulatory / IP barriers

---

## Phase 2: Growth Analysis (Core of the Framework)

### 2.1 Revenue Growth
- TTM revenue and YoY growth rate
- Last 4–6 quarters of revenue growth trend (accelerating / decelerating / stabilizing?)
- Mix: organic vs. acquired growth
- Geographic exposure and international growth vector

### 2.2 Growth Quality Metrics
For SaaS/subscription businesses:
- **Net Revenue Retention (NRR)** — benchmark: >120% excellent, >110% good, <100% red flag
- **Annual Recurring Revenue (ARR)** or Monthly Recurring Revenue (MRR) trajectory
- **Customer count growth** and **ARPU trend**

For other models:
- Cohort behavior (if disclosed)
- Same-store / same-customer growth
- Backlog or remaining performance obligations (RPO) trend

### 2.3 Rule of 40
`Rule of 40 Score = Revenue Growth % + FCF Margin %`
- >40: healthy for growth stage; >60: exceptional
- Flag if the company relies entirely on growth to hit Rule of 40 (margin component = 0)

### 2.4 Guidance & Forward Estimates
- What is management guiding for next quarter and full year?
- How has guidance accuracy trended? (sandbagging vs. consistent misses)
- Analyst consensus estimates vs. management guide — is there a gap?
- Fetch the most recent earnings guide using web search.

---

## Phase 3: Financial Health

### 3.1 P&L Quality
- Gross margin trend — is it expanding, contracting, or stable? (flag any contraction >200bps)
- Operating leverage: is OpEx growing slower than revenue?
- Stock-based compensation as % of revenue (>20% is a red flag for growth companies)
- GAAP vs. non-GAAP gap — understand what's being excluded and why

### 3.2 Free Cash Flow
- FCF = Operating Cash Flow − CapEx
- FCF margin trend (more important than EBITDA for growth companies)
- FCF conversion from net income — large divergence requires explanation
- Is the company FCF positive? If not, what is the path and timeline?

### 3.3 Balance Sheet
- Cash and equivalents vs. current burn rate → **runway in months**
- Debt: total debt, maturity schedule, covenants
- Dilution risk: share count trend, remaining dilution from options/warrants/converts
- Does the company need to raise capital? If so, at what conditions?

---

## Phase 4: Management & Governance

### 4.1 Management Quality
- Founder-led or professional management?
- Track record: has leadership delivered on past guidance and strategic commitments?
- Insider ownership % — high ownership aligns incentives
- Recent insider buying or selling (fetch from SEC Form 4 data)
- Key person risk

### 4.2 Capital Allocation
- Reinvestment rate into R&D and S&M vs. industry peers
- M&A history: value-accretive or dilutive?
- Buyback program (rare for true growth companies — note if present)

---

## Phase 5: Bear Case (Required — Run Before Bull Case)

Per standing rules, the bear case must be constructed first and taken seriously.

Growth-specific bear case checklist:
- [ ] **Deceleration risk**: What would cause growth to slow materially?
- [ ] **Multiple compression**: What P/S or EV/NTM Revenue is priced in? What re-rating risk exists?
- [ ] **Competitive entry**: Who could take share? Is there a well-funded attacker?
- [ ] **TAM ceiling**: How much of the TAM is already captured?
- [ ] **Margin of safety**: At what price does the thesis break?
- [ ] **Customer concentration**: Top 10 customers as % of revenue
- [ ] **Churn or NRR deterioration**: Any early signals?
- [ ] **Macro sensitivity**: How did the stock and business perform in 2022 rate-rise environment?
- [ ] **Accounting concerns**: See `sec-filing-analysis` skill for red flag checklist

Rate overall bear case severity: **High / Medium / Low** with rationale.

---

## Phase 6: Valuation

See `references/dcf-growth.md` for the full DCF walkthrough.

### Quick Sanity Check (always run first)
- Current EV/NTM Revenue multiple vs. peer group and own history
- EV/Gross Profit (better for comparing different margin profiles)
- PEG ratio if company is profitable
- Implied growth rate in current price (reverse DCF)

### Scenario Framework
Always present three scenarios:

| Scenario | Growth Assumption | Terminal Margin | Discount Rate | Implied Value |
|----------|------------------|-----------------|---------------|---------------|
| Bull     | High-end guidance + expansion | Peers at maturity | WACC −1% | $ |
| Base     | Consensus estimates | Historical trend | WACC | $ |
| Bear     | Deceleration case | Compressed margins | WACC +2% | $ |

---

## Phase 7: Momentum & Technical Context

Growth investing integrates price action. Always note:
- 52-week range and current position within it
- Relative strength vs. S&P 500 and sector peers (3M, 6M, 12M)
- Recent catalyst calendar: next earnings date, investor day, product launches
- Short interest as % of float (elevated short interest = either contrarian opportunity or informed bearishness)
- Institutional ownership changes (13F filings, last quarter)

---

## Output Format

Structure your final output as:

1. **Company Snapshot** (2–3 sentences: what they do, size, stage)
2. **Bull Thesis** (3–5 bullet points)
3. **Bear Case** (3–5 bullet points — equal weight to bull)
4. **Key Metrics Dashboard** (table: growth rate, NRR, gross margin, FCF margin, Rule of 40, EV/NTM Rev)
5. **Valuation Scenarios** (table)
6. **Verdict & Key Monitorables** (what to watch that would change your view)

Always cite sources (filing dates, earnings call dates, prices as of date fetched).
