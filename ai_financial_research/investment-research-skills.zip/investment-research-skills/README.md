# 📈 Investment Research Skills for Claude
### A Due Diligence Toolkit for Growth & Momentum Investing

---

## What's Included

This package contains **4 skills** and **1 rules file** that transform Claude into a
research-grade investment analysis partner, optimized for publicly traded growth companies.

### Skills
| Skill | What It Does |
|-------|-------------|
| `equity-due-diligence` | Full company DD — business model, growth metrics, financials, bear case, DCF valuation |
| `sec-filing-analysis` | Deep reading of 10-K, 10-Q, 8-K, proxy filings — with red flag checklist |
| `earnings-call-analysis` | Transcript analysis, guidance quality, QoQ trend tracking, earnings summary |
| `competitive-landscape` | Moat analysis, Porter's Five Forces, disruption risk (including AI disruption) |

### Rules
| Rule File | What It Does |
|-----------|-------------|
| `investment-research-rules.md` | 10 standing behavioral rules: bear-case-first, scenario valuations, source discipline, momentum context, and more |

---

## How to Install

### Step 1: Get the Files
Download or unzip this package. You should have:
```
investment-research-skills/
├── README.md  ← you are here
├── skills/
│   ├── equity-due-diligence/
│   │   ├── SKILL.md
│   │   └── references/
│   │       └── dcf-growth.md
│   ├── sec-filing-analysis/
│   │   └── SKILL.md
│   ├── earnings-call-analysis/
│   │   └── SKILL.md
│   └── competitive-landscape/
│       └── SKILL.md
└── rules/
    └── investment-research-rules.md
```

### Step 2: Add Skills to Claude

1. Go to **claude.ai** and open **Settings**
2. Navigate to **"Skills"** (or "Custom Instructions" depending on your plan)
3. For each skill folder in `/skills/`:
   - Click **"Add Skill"** or **"Upload Skill"**
   - Upload the entire skill folder (e.g., `equity-due-diligence/`) or paste the SKILL.md content
   - The skill name and trigger description are in the SKILL.md front matter

> **Note**: Skill installation UI may vary by Claude plan (Pro, Team, Enterprise).
> Check https://support.claude.ai for the latest instructions on adding skills.

### Step 3: Add the Rules

Rules are persistent instructions that apply to all conversations:

1. Go to **Settings → "Custom Instructions"** (or "Memory & Personalization")
2. Paste the contents of `rules/investment-research-rules.md` into your custom instructions
3. Save

> Alternatively, you can start any research conversation by pasting the rules file content
> and saying "Please follow these rules for this conversation."

---

## How to Use

Once installed, just talk to Claude naturally:

**Starting a full DD:**
> "Do a deep dive on Palantir for me"
> "Help me research $CRWD — I'm thinking about initiating a position"
> "Build an investment thesis on Shopify"

**Analyzing filings:**
> "Walk me through the red flags to look for in Snowflake's 10-K"
> "I just pasted Datadog's 10-Q MD&A — what stands out?"

**Earnings analysis:**
> "Summarize what happened on MongoDB's last earnings call"
> "Is this beat-and-raise from HubSpot high quality or not?"

**Competitive analysis:**
> "How durable is Cloudflare's moat?"
> "Could AI disrupt ServiceNow's business?"

---

## Tips for Best Results

- **Enable web search** in Claude settings — these skills are designed to fetch live data
- For SEC filings, you can paste filing text directly into the chat and Claude will analyze it
- For earnings calls, paste the transcript or give Claude the company name and it will search
- Ask Claude to focus on specific phases: "Just do the bear case" or "Skip to valuation"
- Use the rules file as a conversation starter if you haven't installed it permanently

---

## About These Skills

These skills were built for a **growth and momentum investing** style. They prioritize:
- Revenue growth quality and durability over current profitability
- Rule of 40, NRR, and ARR metrics alongside traditional financials
- Relative price strength as a complement to fundamental analysis
- DCF frameworks adapted for terminal-value-dominated growth company valuations

They are intentionally **sector-agnostic** — applicable to any publicly traded company.

---

*These skills are tools to augment research, not replace judgment. Nothing here constitutes
financial advice. Always do your own diligence before making investment decisions.*
